Fonts can be found here - https://fonts.google.com/specimen/Raleway



Icons can be found here - https://fontawesome.com/



Colours:
	
White #f2f2f2

Green 26a682

Black #3c3b3a